# ExecutiveOS Design System & Brand Bible

The single source of truth for every design, UX, and brand decision across ExecutiveOS.

**Start here:** [`EXECUTIVEOS_DESIGN_BIBLE.md`](./EXECUTIVEOS_DESIGN_BIBLE.md) — master document combining all recommendations.

---

## Document Index

| # | Document | Purpose |
|---|----------|---------|
| — | [**EXECUTIVEOS_DESIGN_BIBLE.md**](./EXECUTIVEOS_DESIGN_BIBLE.md) | **Master standard** — vision, brand, colors, typography, logo, motion, UX, UI, roadmap |
| 1 | [BRAND_STRATEGY.md](./BRAND_STRATEGY.md) | Purpose, mission, personality, voice, tone, writing principles |
| 2 | [VISUAL_IDENTITY.md](./VISUAL_IDENTITY.md) | Color palette, typography, spacing, elevation, light/dark mode, accessibility |
| 3 | [LOGO_SYSTEM.md](./LOGO_SYSTEM.md) | 10 logo concepts, evaluation criteria, recommended direction (The Meridian) |
| 4 | [DESIGN_PRINCIPLES.md](./DESIGN_PRINCIPLES.md) | Core design principles — clarity, hierarchy, progressive disclosure |
| 5 | [UX_PRINCIPLES.md](./UX_PRINCIPLES.md) | Executive user model, navigation, search, keyboard, error recovery |
| 6 | [INTELLIGENCE_CENTER_UX.md](./INTELLIGENCE_CENTER_UX.md) | Dashboard experience — priority strip, cards, timeline, health score |
| 7 | [CONCIERGE_ONBOARDING.md](./CONCIERGE_ONBOARDING.md) | Conversational onboarding — Executive Digital Twin journey |
| 8 | [MOTION_SYSTEM.md](./MOTION_SYSTEM.md) | Animation timing, transitions, loading, micro-interactions |
| 9 | [COMPONENT_GUIDELINES.md](./COMPONENT_GUIDELINES.md) | Cards, tables, buttons, forms, charts, graph, advisor panel |
| 10 | [BRAND_APPLICATION.md](./BRAND_APPLICATION.md) | Website, decks, email, LinkedIn, merchandise, executive reports |
| 11 | [DESIGN_ROADMAP.md](./DESIGN_ROADMAP.md) | Beta → v1.0 → enterprise priorities and design debt |

---

## Design North Star

> **Trust before excitement. Clarity before density. Calm before complexity.**

ExecutiveOS should feel like the software used by Fortune 500 CEOs — calm, confident, intelligent, premium, trustworthy, proactive. Never overwhelming.

---

## Quick Reference

### Colors

| Token | HEX | Usage |
|-------|-----|-------|
| Ink 900 | `#0F1419` | Primary brand, buttons, priority strip |
| Slate 900 | `#18181B` | Primary text |
| Slate 600 | `#52525B` | Secondary text |
| Slate 200 | `#E4E4E7` | Borders |
| Meridian Blue | `#2563EB` | Links, selected states |
| Success | `#059669` | On-track |
| Warning | `#D97706` | At-risk |
| Critical | `#DC2626` | Immediate attention (max 1–2/screen) |

### Typography

Geist Sans (UI) · Geist Mono (scores, IDs) · 15px body · 11px overlines

### Logo

**The Meridian** — horizontal line with vertical intersection. Ink 900. See [LOGO_SYSTEM.md](./LOGO_SYSTEM.md).

### Every Screen Must Answer

1. What requires my attention?
2. Why?
3. What should I do?

---

## Related Documentation

- Product strategy: [`/docs/business/PRODUCT_STRATEGY.md`](../business/PRODUCT_STRATEGY.md)
- Beta program: [`/docs/business/BETA_PROGRAM.md`](../business/BETA_PROGRAM.md)
- UI implementation: `src/components/ui/`
- Intelligence Center: `src/components/intelligence-center/`

---

## Governance

All new features, pages, and external assets must reference the Design Bible before implementation. Propose changes via PR to `/docs/design/`.

**Version:** 1.0 · **Status:** Canonical · **Owner:** Product & Design
